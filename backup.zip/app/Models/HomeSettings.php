<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeSettings extends Model
{
   protected $table = 'home';

   // public $timestamps = false;
   // protected $fillable=['name','image'];
}