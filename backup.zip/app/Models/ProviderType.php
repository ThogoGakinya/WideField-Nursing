<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProviderType extends Model
{
    protected $table = "provider_types";
    // public $timestamps = false;
}
