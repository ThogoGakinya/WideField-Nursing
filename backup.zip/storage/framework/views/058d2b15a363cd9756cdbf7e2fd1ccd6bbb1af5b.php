<?php $__env->startSection('page_title',trans('labels.add_service')); ?>
<?php $__env->startSection('content'); ?>
	<section id="basic-form-layouts">
		<div class="row">
			<div class="col-md-12">
  			<div class="card">
      		<div class="card-header">
						<h4 class="card-title" id="horz-layout-colored-controls"><?php echo e(trans('labels.add_service')); ?></h4>
      		</div>
      		<div class="card-body">
         		<div class="px-3">
				    	<form class="form form-horizontal" id="add_service_form" action="<?php echo e(URL::to('services-store')); ?>" method="POST" enctype="multipart/form-data">
							<?php echo csrf_field(); ?>
              	<div class="form-body">

              		<div class="row">
              			
              			<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-3 label-control" for="name"><?php echo e(trans('labels.service')); ?></label>
												<div class="col-md-9">
													<input type="text" id="add_service_name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(trans('labels.enter_service')); ?>">
													<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="name_error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-3 label-control" for="category_id"> <?php echo e(trans('labels.category')); ?> </label>
												<div class="col-md-9">
													<select id="add_service_category_id" name="category_id" class="form-control <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-toggle="tooltip" data-trigger="hover" data-placement="top" data-title="category_id">
														<option value="" selected disabled><?php echo e(trans('labels.select')); ?></option>
														<?php $__currentLoopData = $categorydata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<option value="<?php echo e($cd->id); ?>"><?php echo e($cd->name); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</select>
													<?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="category_id_error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</div>
										</div>
                 	</div>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-3 label-control" for="image"><?php echo e(trans('labels.image')); ?></label>
												<div class="col-md-9">
													<input type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="service_image" name="image" accept=".jpg,.jpeg,.png" value="<?php echo e(old('image')); ?>">
													<?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="image_error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-3 label-control" for="gallery_image"><?php echo e(trans('labels.gallery')); ?></label>
												<div class="col-md-9">
													<input type="file" id="add_service_gallery_image" class="form-control <?php if($errors->has('gallery_image.*')): ?> is-invalid <?php endif; ?>" name="gallery_image[]" accept="image/*" multiple>
													<?php $__errorArgs = ['gallery_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="gallery_image_error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>		
													<?php if($errors->has('gallery_image.*')): ?>
														<span class="text-danger"><?php echo e($errors->first('gallery_image.*')); ?></span>
													<?php endif; ?>
												</div>
											</div>
										</div>
									</div>
	                <div class="row">
										<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-3 label-control" for="price"><?php echo e(trans('labels.price')); ?></label>
												<div class="col-md-9 ">
													<input type="text" id="service_price" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price" value="<?php echo e(old('price')); ?>" placeholder="<?php echo e(trans('labels.enter_price')); ?>">
													<?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="priceError"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</div>
										</div>
                  </div>
                  <!--Date Time Picker-->
                  <div class="row">
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label class="col-md-3 label-control" for="from_time">From</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control pickatime" placeholder="Starting time" id="from_time_picker" name="start_time[]"/>
                               </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label class="col-md-3 label-control" for="to_time"><?php echo e(trans('labels.to')); ?></label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control pickatime" placeholder="Stoppage time" id="to_time_picker" name="finish_time[]"/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Date Time Picker-->

                 	<div class="row">
										<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-3 label-control" for="price_type"><?php echo e(trans('labels.price_type')); ?></label>
												<div class="col-md-9">
													<div class="form-check form-check-inline">
														<input class="form-check-input" type="radio" name="price_type" onChange="getduration(this)" id="fixed" value="Fixed" checked="checked">
														<label class="form-check-label" for="fixed"><?php echo e(trans('labels.fixed')); ?></label>
													</div>
													<!--<div class="form-check form-check-inline">-->
													<!--	<input class="form-check-input" type="radio" name="price_type" onChange="getduration(this)" id="hourly" value="Hourly" <?php if(old('price_type') == 'Hourly'): ?> checked <?php endif; ?>>-->
													<!--	<label class="form-check-label" for="hourly"><?php echo e(trans('labels.hourly')); ?></label>-->
													<!--</div>-->
													<?php $__errorArgs = ['price_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="price_type_error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</div>
											<div class="form-group row <?php if(old('price_type') == 'Hourly'): ?> dn <?php endif; ?>" id="duration_type">
												<label class="col-md-3 label-control" for="duration_type"><?php echo e(trans('labels.type')); ?></label>
												<div class="col-md-9 ">
													<select class="form-control selectbox select" name="duration_type" >
														<!--<option <?php if(old('duration_type') == "1"): ?> selected <?php endif; ?> value="1"> <?php echo e(trans('labels.minutes')); ?> </option>-->
														<option <?php if(old('duration_type') == "2"): ?> selected <?php endif; ?> value="2"> <?php echo e(trans('labels.hours')); ?> </option>
														<!--<option <?php if(old('duration_type') == "3"): ?> selected <?php endif; ?> value="3"> <?php echo e(trans('labels.days')); ?> </option>-->
													</select>
													<?php $__errorArgs = ['duration_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="duration_type_error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</div>
											<div class="form-group row <?php if(old('price_type') == 'Hourly'): ?> dn <?php endif; ?>" id="duration">
												<label class="col-md-3 label-control" for="duration"><?php echo e(trans('labels.duration')); ?></label>
												<div class="col-md-9 ">
													<input type="text" id="service_duration" class="form-control <?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="duration" value="<?php echo e(old('duration')); ?>" placeholder="<?php echo e(trans('labels.enter_duration')); ?>">
													<?php $__errorArgs = ['duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="duration_error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group row">
												<label class="col-md-3 label-control" for="featured"><?php echo e(trans('labels.featured')); ?> </label>
												<div class="col-md-9">
                         	<div class="form-check form-switch">
                            <input class="form-check-input " type="checkbox" id="is_featured" name="is_featured" value="is_featured">
                            <label class="form-check-label " for="is_featured"><?php echo e(trans('labels.set_as_featured')); ?></label>
                         	</div>
													<?php $__errorArgs = ['is_featured'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="is_featured_error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</div>
											<div class="form-group row">
												<label class="col-md-3 label-control" for="description"><?php echo e(trans('labels.description')); ?> </label>
												<div class="col-md-9">
													<textarea id="add_service_description" rows="2" class="form-control col-md-12 <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" placeholder="<?php echo e(trans('labels.service_description')); ?>"><?php echo e(old('description')); ?></textarea>
													<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="descriptionError"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
												</div>
											</div>
										</div>
                  </div>
                  
								</div>
								<div class="form-actions left">
										<a class="btn btn-raised btn-danger mr-1" href="<?php echo e(URL::to('services')); ?>"> <i class="fa fa-arrow-left"></i> <?php echo e(trans('labels.back')); ?> </a>
										<?php if(env('Environment') == 'sendbox'): ?>
                     	<button type="button" onclick="myFunction()" class="btn btn-raised btn-primary"> <i class="fa fa-paper-plane"></i> <?php echo e(trans('labels.add')); ?> </button>
                   	<?php else: ?>
											<button type="submit" id="btn_add_service" class="btn btn-raised btn-primary"> <i class="fa fa-paper-plane"></i> <?php echo e(trans('labels.add')); ?> </button>
										<?php endif; ?>
								</div>
							</form>
         		</div>
      		</div>
  			</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script src="<?php echo e(asset('storage/app/public/admin-assets/js/jquery.timepicker.js')); ?>" defer></script>
  <script src="<?php echo e(asset('resources/views/service/service.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/medgorid/widefieldmedical.com/resources/views/service/add.blade.php ENDPATH**/ ?>