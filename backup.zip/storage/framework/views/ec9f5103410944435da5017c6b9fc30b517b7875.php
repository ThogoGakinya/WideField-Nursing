<?php $__env->startSection('page_title',trans('labels.add_category')); ?>
<?php $__env->startSection('content'); ?>
   <section id="basic-form-layouts">
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-header">
                  <h1 class="card-title"><?php echo e(trans('labels.add_category')); ?></h1>
               </div>
               <div class="card-body">
                  <div class="px-3">
                     <form class="form" id="add_categpry_form" action="<?php echo e(URL::to('/categories/store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-body">
                           <div class="form-group">
                              <label for="name"><?php echo e(trans('labels.category_name')); ?></label>
                              <input type="text" id="category_name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(trans('labels.enter_category')); ?>">
                              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="name_error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="form-group">
                              <label><?php echo e(trans('labels.category_image')); ?></label>
                              <input type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="category_image" name="image" accept=".jpg,.png,.jpeg">
                              <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger" id="image_error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>   
                           <div class="form-check form-switch">
                              <input class="form-check-input" type="checkbox" id="is_featured" name="is_featured" value="is_featured">
                              <label class="form-check-label" for="is_featured"><?php echo e(trans('labels.is_featured')); ?></label>
                           </div>
                           <div class="form-actions">
                              <a class="btn btn-danger" href="<?php echo e(URL::to('/categories')); ?>"> <i class="fa fa-arrow-left"></i><?php echo e(trans('labels.back')); ?> </a>
                              <?php if(env('Environment') == 'sendbox'): ?>
                                 <button type="button" class="btn btn-raised btn-primary" onclick="myFunction()"> <i class="fa fa-paper-plane"></i><?php echo e(trans('labels.add')); ?></button>
                              <?php else: ?>
                                  <button type="submit" id="btn_add_category" class="btn btn-raised btn-primary"> <i class="fa fa-paper-plane"></i><?php echo e(trans('labels.add')); ?></button>
                              <?php endif; ?>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/medgorid/widefieldmedical.com/resources/views/category/add.blade.php ENDPATH**/ ?>