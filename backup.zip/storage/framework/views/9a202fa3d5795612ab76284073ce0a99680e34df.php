   <table class="table table-striped table-bordered zero-configuration">
      <thead>
         <tr>
            <th><?php echo e(trans('labels.srno')); ?></th>
            <th><?php echo e(trans('labels.image')); ?></th>
            <th><?php echo e(trans('labels.service_name')); ?></th>
            <th><?php echo e(trans('labels.category_name')); ?></th>
            <th><?php echo e(trans('labels.price')); ?></th>
            <th><?php echo e(trans('labels.duration')); ?></th>
            <th><?php echo e(trans('labels.featured')); ?></th>
            <th><?php echo e(trans('labels.status')); ?></th>
            <th><?php echo e(trans('labels.action')); ?></th>
            <th><?php echo e(trans('labels.from')); ?></th>
            <th><?php echo e(trans('labels.to')); ?></th>
         </tr>
      </thead>
      <tbody>
         <?php $i = 1;?>
         <?php $__currentLoopData = $servicedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>    
               <td><?=$i++;?></td> 
               <td><img src="<?php echo e(Helper::image_path($sdata->image)); ?>" alt="<?php echo e(trans('labels.service')); ?>" class="rounded table-image"></td>
               <td><?php echo e($sdata->name); ?></td>
               <td><?php echo e($sdata['categoryname']->name); ?></td>
               <td><?php echo e(Helper::currency_format($sdata->price)); ?></td>
               <td>
                  <?php if($sdata->price_type == "Fixed"): ?>
                     <?php if($sdata->duration_type == 1): ?>
                        <?php echo e($sdata->duration.trans('labels.minutes')); ?>

                     <?php elseif($sdata->duration_type == 2): ?>
                        <?php echo e($sdata->duration.trans('labels.hours')); ?>

                     <?php elseif($sdata->duration_type == 3): ?>
                        <?php echo e($sdata->duration.trans('labels.days')); ?>

                     <?php else: ?>
                        <?php echo e($sdata->duration.trans('labels.minutes')); ?>

                     <?php endif; ?>
                  <?php else: ?>
                     <?php echo e($sdata->price_type); ?>

                  <?php endif; ?>
               </td>
               <!--<td>-->
               <!--   <?php if($sdata->discount > 0): ?>-->
               <!--      <?php echo e($sdata->discount); ?>%-->
               <!--   <?php endif; ?>-->
               <!--</td>-->
               <?php if(Auth::user()->type == 2): ?>
                  <td>
                     <?php if(env('Environment') == 'sendbox'): ?>
                        <?php if($sdata->is_featured == 1): ?>
                           <a class="success p-0" onclick="myFunction()"><i class="ft-check font-medium-3 mr-2"></i></a>
                        <?php else: ?>
                           <a class="danger p-0" onclick="myFunction()"><i class="ft-x font-medium-3 mr-2"></i></a>
                        <?php endif; ?>
                     <?php else: ?>
                        <?php if($sdata->is_featured == 1): ?>
                           <a class="success p-0" onclick="updateserviceisfeatured('<?php echo e($sdata->id); ?>','2','<?php echo e(trans('messages.are_you_sure')); ?>','<?php echo e(trans('messages.yes')); ?>','<?php echo e(trans('messages.no')); ?>','<?php echo e(URL::to('services/edit/is_featured')); ?>','<?php echo e(trans('messages.wrong')); ?>','<?php echo e(trans('messages.record_safe')); ?>')"><i class="ft-check font-medium-3 mr-2"></i></a>
                        <?php else: ?>
                           <a class="danger p-0" onclick="updateserviceisfeatured('<?php echo e($sdata->id); ?>','1','<?php echo e(trans('messages.are_you_sure')); ?>','<?php echo e(trans('messages.yes')); ?>','<?php echo e(trans('messages.no')); ?>','<?php echo e(URL::to('services/edit/is_featured')); ?>','<?php echo e(trans('messages.wrong')); ?>','<?php echo e(trans('messages.record_safe')); ?>')"><i class="ft-x font-medium-3 mr-2"></i></a>
                        <?php endif; ?>
                     <?php endif; ?>
                  </td>
                  <td>
                     <?php if(env('Environment') == 'sendbox'): ?>
                        <?php if($sdata->is_available == 1): ?>
                           <a class="success p-0" onclick="myFunction()"><i class="ft-check font-medium-3 mr-2"></i></a>
                        <?php else: ?>
                           <a class="danger p-0" onclick="myFunction()"><i class="ft-x font-medium-3 mr-2"></i></a>
                        <?php endif; ?>
                     <?php else: ?>
                        <?php if($sdata->is_available == 1): ?>
                           <a class="success p-0" onclick="updateservicestatus('<?php echo e($sdata->id); ?>','2','<?php echo e(trans('messages.are_you_sure')); ?>','<?php echo e(trans('messages.yes')); ?>','<?php echo e(trans('messages.no')); ?>','<?php echo e(URL::to('services/edit/status')); ?>','<?php echo e(trans('messages.wrong')); ?>','<?php echo e(trans('messages.record_safe')); ?>')"><i class="ft-check font-medium-3 mr-2"></i></a>
                        <?php else: ?>
                           <a class="danger p-0" onclick="updateservicestatus('<?php echo e($sdata->id); ?>','1','<?php echo e(trans('messages.are_you_sure')); ?>','<?php echo e(trans('messages.yes')); ?>','<?php echo e(trans('messages.no')); ?>','<?php echo e(URL::to('services/edit/status')); ?>','<?php echo e(trans('messages.wrong')); ?>','<?php echo e(trans('messages.record_safe')); ?>')"><i class="ft-x font-medium-3 mr-2"></i></a>
                        <?php endif; ?>
                     <?php endif; ?>
                  </td>
               <?php else: ?>
                  <td><i class="<?php if($sdata->is_featured == 1): ?> success ft-check <?php else: ?> danger ft-x <?php endif; ?> font-medium-3 mr-2"></i></td>
                  <td><i class="<?php if($sdata->is_available == 1): ?> success ft-check <?php else: ?> danger ft-x <?php endif; ?> font-medium-3 mr-2"></i></td>
               <?php endif; ?>
               <td>
                  <?php if(Auth::user()->type == 2): ?>
                     <a class="info p-0" href="<?php echo e(URL::to('/services/edit/'.$sdata->slug)); ?>"><i class="ft-edit font-medium-3 mr-2"></i></a>
                     <?php if(env('Environment') == 'sendbox'): ?>
                        <a class="danger p-0" onclick="myFunction()" ><i class="ft-trash font-medium-3 mr-2"></i></a>
                     <?php else: ?>
                        <a class="danger p-0" onclick="deleteservice('<?php echo e($sdata->id); ?>','<?php echo e(trans('messages.are_you_sure')); ?>','<?php echo e(trans('messages.yes')); ?>','<?php echo e(trans('messages.no')); ?>','<?php echo e(URL::to('/services-del')); ?>','<?php echo e(trans('messages.wrong')); ?>','<?php echo e(trans('messages.record_safe')); ?>')" ><i class="ft-trash font-medium-3 mr-2"></i></a>
                     <?php endif; ?>
                  <?php endif; ?>
                  <a class="dark p-0" href="<?php echo e(URL::to('/services/'.$sdata->slug)); ?>"><i class="ft-eye font-medium-3 mr-2"></i></a>
               </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table><?php /**PATH /home/medgorid/widefieldmedical.com/resources/views/service/service_table.blade.php ENDPATH**/ ?>