<?php $__env->startSection('page_title',trans('labels.home')); ?>
<?php $__env->startSection('content'); ?>


   <section class="hero-section">
      <div class="layer">
         <div class="home-banner" style="background-image:url('<?php echo e(Helper::image_path(Helper::appdata()->banner)); ?>')"></div>
         <div class="container">
            <div class="row justify-content-center">
               <div class="col-lg-12">
                  <div class="section-search">
                     <h3><?php echo e(trans('labels.banner_main_title')); ?></h3>
                     <p><?php echo e(trans('labels.banner_sub_title')); ?></p>
                     <div class="search-box">
                        <div class="search-input w-100">
                           <i class="fas fa-search bficon"></i>
                           <div class="form-group mb-0">
                              <input type="text" class="form-control" name="search_box" id="search_box" placeholder="<?php echo e(trans('labels.looking_for_service')); ?>" ">   <!--url="<?php echo e(URL::to('/home/find-service')); ?> -->
                              <div class="item-list" id="suggestion" ></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>

   <?php if(!empty($bannerdata) && count($bannerdata)>0): ?>
      <section class="popular-services">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-12">
                  <div class="service-carousel">
                     <div class="service-slider owl-carousel owl-theme">
                        <?php $__currentLoopData = $bannerdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="service-widget">
                              <a href="<?php if($bdata['service_id'] != ''): ?> <?php echo e(URL::to('/home/service-details/'.$bdata['service_slug'])); ?> <?php elseif($bdata['category_id'] != ''): ?> <?php echo e(URL::to('/home/services/'.$bdata['category_slug'])); ?> <?php else: ?> href='#' <?php endif; ?> ">
                                 <img class="img-fluid serv-imgn rounded popular-services-img" src="<?php echo e(Helper::image_path($bdata['image'])); ?>" alt="<?php echo e(trans('labels.service_image')); ?>">
                              </a>
                           </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   <?php endif; ?>

   <!-- Category section 
   <section class="category-section">
      <div class="container-fluid"> 
         <div class="row">
            <div class="col-lg-12">
               <div class="row">
                  <div class="col-md-6">
                     <div class="heading">
                        <h2><?php echo e(trans('labels.featured_categories')); ?></h2>
                        <span><?php echo e(trans('labels.what_looking_for')); ?></span>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="viewall">
                        <h4><a href="<?php echo e(URL::to('/home/categories')); ?>"> <?php echo e(trans('labels.view_all')); ?> <i class="fas fa-angle-right"></i></a></h4>
                        <span><?php echo e(trans('labels.featured_categories')); ?></span>
                     </div>
                  </div>
               </div>
               <?php echo $__env->make('front.category_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>           
             </div>
         </div>
      </div>
   </section>
-->

   <!-- Services section 
   <section class="popular-services">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-12">
               <div class="row">
                  <div class="col-md-6">
                     <div class="heading">
                        <h2><?php echo e(trans('labels.popular_services')); ?></h2>
                        <span><?php echo e(trans('labels.explore_services')); ?></span>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="viewall">
                        <h4><a href="<?php echo e(URL::to('/home/services')); ?>"><?php echo e(trans('labels.view_all')); ?><i class="fas fa-angle-right"></i></a></h4>
                        <span><?php echo e(trans('labels.most_popular')); ?></span>
                     </div>
                  </div>
               </div>
               <div class="catsec">
                  <?php if(!empty($servicedata) && count($servicedata)>0): ?>
                  <div class="row">
                     <?php echo $__env->make('front.service_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <?php else: ?>
                     <p class="text-center"><?php echo e(trans('labels.no_data')); ?></p>
                  <?php endif; ?>
               </div>
            </div>
         </div>
      </div>
   </section>

-->
   <!-- Providers section 
   <section class="popular-services">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-12">
               <div class="row">
                  <div class="col-md-6">
                     <div class="heading">
                        <h2><?php echo e(trans('labels.top_providers')); ?></h2>
                        <span><?php echo e(trans('labels.trust_providers')); ?></span>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="viewall">
                        <h4><a href="<?php echo e(URL::to('/home/providers')); ?>"><?php echo e(trans('labels.view_all')); ?><i class="fas fa-angle-right"></i></a></h4>
                        <span><?php echo e(trans('labels.top_providers')); ?></span>
                     </div>
                  </div>
               </div>
               <div class="catsec">
                  <?php if(!empty($providerdata) && count($providerdata)>0): ?>
                     <div class="row">
                        <?php echo $__env->make('front.provider_section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     </div>
                  <?php else: ?>
                     <p class="text-center"><?php echo e(trans('labels.no_data')); ?></p>
                  <?php endif; ?>
               </div>
            </div>
         </div>
      </div>
   </section>
   -->
   <?php echo $__env->make('front.how_work', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.home_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/medgorid/widefieldmedical.com/resources/views/front/home.blade.php ENDPATH**/ ?>