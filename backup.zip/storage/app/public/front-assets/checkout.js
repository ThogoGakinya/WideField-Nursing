	function openaddressform(){
		"use strict";
	    $("#addressform").show();
	    $('input[name="address"]').prop('checked', false);
	}
	function closeaddressform(){
		"use strict";
	    $("#addressform").hide();
	}

	function proceed_payment(e) {
		"use strict";
		var date = $('#date').val();
		var timeSplit = $('#time').val().split(':'),hours,minutes,meridian;
	  	hours = timeSplit[0];
	  	minutes = timeSplit[1];
	  	if (hours > 12) {
	    	meridian = 'PM';
	    	hours -= 12;
	  	} else if (hours < 12) {
	    	meridian = 'AM';
	    	if (hours == 0) { hours = 12; }
	  	} else {
	    	meridian = 'PM';
	  	}
		var time = hours + ':' + minutes + ' ' + meridian;

	    var ptype_err_text = $('#select_ptype').val();
	    var date_time_err_text = $('#date_time_err_text').val();
	    var address_err_text = $('#address_err_text').val();
	    var title = $('#title').val();
	    var description = $('#description').val();
	    var logo = $('#logo').val();
	    var booking_url = $('#booking_url').val();
	    var success_url = $('#success_url').val();
	    var user_id = $('#user_id').val();
		var service = $('#service').val();
		var fullname =  $('input[name="address"]:checked').attr("data-fullname");
	    var email =  $('input[name="address"]:checked').attr("data-email");
	    var mobile =  $('input[name="address"]:checked').attr("data-mobile");
	    var street =  $('input[name="address"]:checked').attr("data-street_address");
	    var landmark =  $('input[name="address"]:checked').attr("data-landmark");
	    var postcode =  $('input[name="address"]:checked').attr("data-postcode");
	    var booking_notes = $('#booking_notes').val();
	    var payment_type = $('input[name="payment"]:checked').attr("data-payment_type");
		var service_id = $('#service_id').val();
		var coupon_code = $('#coupon_code').val();
		var price = $('#price').val();
	    var discount = $('#discount').val();
	    var total_price = $('#total_price').val();

		if ($('input[name="address"]:checked').length <= 0){
         	$('#address_err').text(address_err_text).addClass('alert alert-danger mb-1').css("display","block");
        	setTimeout(function() {
            	$("#address_err").hide();
            }, 5000);
            return false;
      	}
	    if ($('input[name="payment"]:checked').length <= 0){
         	$('#err_msg').text(ptype_err_text).addClass('alert alert-danger mb-1').css("display","block");
        	setTimeout(function() {
            	$("#err_msg").hide();
            }, 5000);
            return false;
      	}
      	if (date == "" || timeSplit == ""){
         	$('#date_time_err_msg').text(date_time_err_text).addClass('alert alert-danger mb-1').css("display","block");
        	setTimeout(function() {
            	$("#date_time_err_msg").hide();
            }, 5000);
            return false;
      	}

	    // COD
        if (payment_type == 1) {
    	    $.ajax({
    	        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
    	        url:booking_url,
    	        data: {
    	            service: service,
	            	date: date,
	            	time: time,
	            	fullname : fullname,
	            	email : email,
	            	mobile: mobile,  
	            	street: street,
	            	landmark: landmark,
	            	postcode: postcode , 
	            	booking_notes : booking_notes,
	            	payment_type : payment_type,
	            	service_id: service_id,
	            	coupon_code : coupon_code ,
	            	discount : discount,
	            	total_price : total_price,
	            	user_id : user_id ,
    	        }, 
    	        method: 'POST',
    	        beforeSend: function(){
			        $('.page-loading').show();
			    },
    	        success: function(response) {
    	        	$('.page-loading').hide();
	                if (response.status == 1) {
	                    window.location.href = success_url;
	                } else {
	                	$('#error').text(response.message).addClass('alert alert-danger mb-1').css("display","block");
	                }
	            },
	            error: function(error) {
	                $('#error').text(error).addClass('alert alert-danger mb-1').css("display","block");
	            }
    	    });
    	}

		// Wallet
    	if (payment_type == 2) {
    		$.ajax({
    	        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
    	        url:booking_url,
    	        data: {
    	        	service: service,
	            	date: date,
	            	time: time,
	            	fullname : fullname,
	            	email : email,
	            	mobile: mobile,  
	            	street: street,
	            	landmark: landmark,
	            	postcode: postcode , 
	            	booking_notes : booking_notes,
	            	payment_type : payment_type,
	            	service_id: service_id,
	            	coupon_code : coupon_code ,
	            	discount : discount,
	            	total_price : total_price,
	            	user_id : user_id ,
    	        }, 
    	        method: 'POST',
    	        beforeSend: function(){
					        $('.page-loading').show();
					    },
    	        success: function(response) {
    	        	$('.page-loading').hide();
	                if (response.status == 1) {
	                    window.location.href = success_url;
	                } else {
						$('#wallet_error').text(response.message).show();
			            setTimeout(function() {
			                $("#wallet_error").hide();
			            }, 10000);
	                }
	            },
	            error: function(error) {
	                $('#error').text(error).addClass('alert alert-danger mb-1').css("display","block");
	            }
    	    });
    	}

		// Razorpay
		if (payment_type == 3) {
			var options = {
	    	    "key": $('#razorpay').val(),
	    	    "amount": (parseInt(total_price*100)), // 2000 paise = INR 20
	    	    "name": "Service Provider",
	    	    "description": "Service Booking payment",
	    	    "image": logo,
	    	    "handler": function (response){
	    	    	$.ajax({
	    	        	headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
	    	            url:booking_url,
	    	            type: 'post',
	    	            dataType: 'json',
	    	            data: {
	    	            	service: service,
	    	            	payment_id: response.razorpay_payment_id,
	    	            	date: date,
	    	            	time: time,
	    	            	fullname : fullname,
	    	            	email : email,
	    	            	mobile: mobile,  
	    	            	street: street,
	    	            	landmark: landmark,
	    	            	postcode: postcode , 
	    	            	booking_notes : booking_notes,
	    	            	payment_type : payment_type,
	    	            	service_id: service_id,
	    	            	coupon_code : coupon_code ,
	    	            	discount : discount,
	    	            	total_price : total_price,
	    	            	user_id : user_id ,
	    	            }, 
	    	            beforeSend: function(){
					        $('.page-loading').show();
					    },
	    	            success: function(response) {
	    	            	$('.page-loading').hide();
	    	                if (response.status == 1) {
	    	                    window.location.href = success_url;
	    	                } else {
	    	                	$('#error').text(response.message).addClass('alert alert-danger mb-1').css("display","block");
	    	                }
	    	            },
	    	            error: function(error) {
	    	            	$('#error').text(error).addClass('alert alert-danger mb-1').css("display","block");
	    	            }
	    	    	});
	    	    },
	    	    "prefill": {
	    	        "contact": mobile,
	    	        "email":   email,
	    	        "name":   fullname,
	    	    },
	    	    "theme": {
	    	        "color": "#366ed4"
	    	    }
	    	}
			var rzp1 = new Razorpay(options);
	    	rzp1.open();
	    	e.preventDefault();
		}

		// Stripe
		if(payment_type == 4){
			var handler = StripeCheckout.configure({
	    	  key: $('#stripe').val(),
	    	  image: logo,
	    	  locale: 'auto',
	    	  token: function(token) {
	    	    // You can access the token ID with `token.id`.
	    	    // Get the token ID to your server-side code for use.

	    	    $.ajax({
	    	        headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
	    	        url:booking_url,
	    	        data: {
	    	            service: service,
    	            	stripeToken : token.id,
    	            	service_id: service_id,
    	            	date: date,
    	            	time: time,
    	            	fullname : fullname,
    	            	email : email,
    	            	mobile: mobile,  
    	            	street: street,
    	            	landmark: landmark,
    	            	postcode: postcode , 
    	            	booking_notes : booking_notes,
    	            	payment_type : payment_type,
    	            	coupon_code : coupon_code ,
    	            	discount : discount,
    	            	total_price : total_price,
    	            	user_id : user_id ,
	    	        }, 
	    	        method: 'POST',
	    	        beforeSend: function(){
					        $('.page-loading').show();
					    },
	    	        success: function(response) {
	    	        	$('.page-loading').hide();
    	                if (response.status == 1) {
    	                    window.location.href = success_url;
    	                } else {
    	                	$('#error').text(response.message).addClass('alert alert-danger mb-1').css("display","block");
    	                }
    	            },
    	            error: function(error) {
    	                $('#error').text(error).addClass('alert alert-danger mb-1').css("display","block");
    	            }
	    	    });
	    	  },
	    	  opened: function() {
	    	    
	    	  },
	    	  closed: function() {

	    	  }
	    	});

	    	//Stripe Popup
	    	handler.open({
	    	    name: title,
	    	    description: description,
	    	    amount: total_price*100,
	    	    currency: "INR",
	    	    email: email
	    	});
	    	e.preventDefault();

    		// Close Checkout on page navigation:
    		$(window).on('popstate', function() {
    	  		handler.close();
    		});
		}

		// Flutterwave
		if(payment_type == 5){

			FlutterwaveCheckout({

		        public_key: $('#flutterwave').val(),
		        tx_ref: "RX1",
		        amount: 100,
		        currency: "USD",
		        country: "US",
		        payment_options: " ",
		        meta: {
		            consumer_id: user_id,
		        },
		        customer: {
		            email: email,
		            name: name,
		        },
		        callback: function (data) {

		        	$.ajax({
		    	    	headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
		    	        url:booking_url,
		    	        method: 'POST',
		    	        dataType: 'json',
		    	        data: {
		    	        	payment_id: data.flw_ref ,
		    	        	service: service,
	    	            	date: date,
	    	            	time: time,
	    	            	fullname : fullname,
	    	            	email : email,
	    	            	mobile: mobile,  
	    	            	street: street,
	    	            	landmark: landmark,
	    	            	postcode: postcode , 
	    	            	booking_notes : booking_notes,
	    	            	payment_type : payment_type,
	    	            	service_id: service_id,
	    	            	coupon_code : coupon_code ,
	    	            	discount : discount,
	    	            	total_price : total_price,
	    	            	user_id : user_id ,
		    	        }, 
		    	        beforeSend: function(){
					        $('.page-loading').show();
					    },
		    	        success: function(response) {
		    	        	$('.page-loading').hide();
	    	                if (response.status == 1) {
	    	                    window.location.href = success_url;
	    	                } else {
								$('#error').text(response.message).addClass('alert alert-danger mb-1').css("display","block");
	    	                }
	    	            },
	    	            error: function(error) {
	    	                $('#error').text(error).addClass('alert alert-danger mb-1').css("display","block");
	    	            }
		    	    });
		        },
		        onclose: function() {
		            // close modal
		        },
		        customizations: {
		            title: title,
		            description: description,
		            logo: logo,
		        },

		    });
		}

		// Paystack
		if(payment_type == 6){

			let handler = PaystackPop.setup({

	            key: $('#paystack').val(),
	            email: "{{Auth::user()->email}}",
	            amount: total_price * 100,
	            currency: 'GHS', // Use GHS for Ghana Cedis or USD for US Dollars
	            ref: ''+Math.floor((Math.random() * 1000000000) + 1),
	            label: title,
	            onClose: function(){
	            },
	            callback: function(response){
	            	$.ajax({
		    	    	headers: {
		    	    	    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
		    	    	},
		    	        url:booking_url,
		    	        method: 'POST',
		    	        dataType: 'json',
		    	        data: {
		    	        	payment_id: response.trxref ,
		    	        	service: service,
	    	            	date: date,
	    	            	time: time,
	    	            	fullname : fullname,
	    	            	email : email,
	    	            	mobile: mobile,  
	    	            	street: street,
	    	            	landmark: landmark,
	    	            	postcode: postcode , 
	    	            	booking_notes : booking_notes,
	    	            	payment_type : payment_type,
	    	            	service_id: service_id,
	    	            	coupon_code : coupon_code ,
	    	            	discount : discount,
	    	            	total_price : total_price,
	    	            	user_id : user_id ,
		    	        }, 
		    	        beforeSend: function(){
					        $('.page-loading').show();
					    },
		    	        success: function(response) {
		    	        	$('.page-loading').hide();
	    	                if (response.status == 1) {
	    	                    window.location.href = success_url;
	    	                } else {
								$('#error').text(response.message).addClass('alert alert-danger mb-1').css("display","block");
	    	                }
	    	            },
	    	            error: function(error) {
	    	                $('#error').text(error).addClass('alert alert-danger mb-1').css("display","block");
	    	            }
		    	    });
	            }
	        });
	        handler.openIframe();
		}
	}