$('#wallet_amt').keyup(function(){
    "use strict";
   var val = $(this).val();
   if(isNaN(val)){
      val = val.replace(/[^0-9\.]/g,'');
      if(val.split('.').length>2) 
         val =val.replace(/\.+$/,"");
      }
   $(this).val(val); 
});

function add_to_wallet(e) {
    "use strict";
      var user_id = $('#user_id').val();
      var name = $('#name').val();
      var contact = $('#mobile').val();
      var email = $('#email').val();
      var amount = $('#wallet_amt').val();
      var payment_type = $('input[name="payment"]:checked').attr("data-payment_type");
      var amt_err_text = $('#amt_err_text').val();
      var ptype_err_text = $('#select_ptype').val();
      var title = $('#title').val();
      var description = $('#description').val();
      var logo = $('#logo').val();
      var add_wallet_url = $('#add_wallet_url').val();
      var wallet_url = $('#wallet_url').val();

        if(amount == ""){
            $('#amt_err_msg').text(amt_err_text).addClass('alert alert-danger mb-1').css("display","block");
            setTimeout(function() {
                $("#amt_err_msg").hide();
            }, 5000);
            return false;
        }
        if ($('input[name="payment"]:checked').length <= 0){

            $('#err_msg').text(ptype_err_text).addClass('alert alert-danger mb-1').css("display","block");
            setTimeout(function() {
                $("#err_msg").hide();
            }, 5000);
            return false;
        }

    // Razorpay
    if (payment_type == 3) {
         
         var options = {
             "key": $('#razorpay').val(),
             "amount": (parseInt(amount*100)), // 2000 paise = INR 20
             "name": title,
             "description": description,
             "image": logo,
             "handler": function (response){
               $.ajax({
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    url:add_wallet_url,
                    type: 'post',
                    dataType: 'json',
                    data: {
                        payment_type : payment_type,
                        transaction_id: response.razorpay_payment_id,
                        amount : amount,
                        user_id : user_id ,
                    }, 
                    success: function(response) {
                        if (response.status == 1) {
                            window.location.href = wallet_url;
                        } else {
                           $('#payment_err_msg').text(response.message).addClass('alert alert-danger mb-1').css("display","block");
                        }
                     },
                    error: function(error) {
                        $('#payment_err_msg').text(error).addClass('alert alert-danger mb-1').css("display","block");
                    }
                });
            },
            "prefill": {
            "name":   name,
                "contact": contact,
                "email":   email,
            },
            "theme": {
                "color": "#366ed4"
            }
            }
        var rzp1 = new Razorpay(options);
        rzp1.open();
        e.preventDefault();
    }

      // Stripe
      if(payment_type == 4){
         var handler = StripeCheckout.configure({
           key: $('#stripe').val(),
           image: logo,
           locale: 'auto',
           token: function(token) {
             $.ajax({
                 headers: {
                     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                 },
                 url:add_wallet_url,
                 data: {
                  payment_type : payment_type,
                     stripeToken : token.id,
                     amount : amount,
                     user_id : user_id ,
                 }, 
                 method: 'POST',
                 success: function(response) {
                      if (response.status == 1) {
                          window.location.href = wallet_url;
                      } else {
                        $('#payment_err_msg').text(response.message).addClass('alert alert-danger mb-1').css("display","block");
                      }
                  },
                  error: function(error) {
                      $('#payment_err_msg').text(error).addClass('alert alert-danger mb-1').css("display","block");
                  }
             });
           },
           opened: function() {
             
           },
           closed: function() {

           }
         });

         //Stripe Popup
         handler.open({
             name: title,
             description: description,
             amount: amount*100,
             currency: "INR",
             email: email
         });
         e.preventDefault();

         // Close Checkout on page navigation:
         $(window).on('popstate', function() {
            handler.close();
         });
      }

      // Flutterwave
      if(payment_type == 5){

         FlutterwaveCheckout({

              public_key: $('#flutterwave').val(),
              tx_ref: "RX1",
              amount: 100,
              currency: "USD",
              country: "US",
              payment_options: " ",
              meta: {consumer_id: user_id,},
              customer: {
                  email: email,
                  phone_number: mobile,
                  name: name,
              },
              callback: function (data) {

               $.ajax({
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    url:add_wallet_url,
                    method: 'POST',
                    dataType: 'json',
                    data: {
                     payment_type : payment_type,
                        amount : amount,
                        user_id : user_id ,
                     transaction_id: data.flw_ref ,
                    }, 
                    success: function(response) {
                         if (response.status == 1) {
                             window.location.href = wallet_url;
                         } else {
                           $('#payment_err_msg').text(response.message).addClass('alert alert-danger mb-1').css("display","block");
                         }
                     },
                     error: function(error) {
                        $('#payment_err_msg').text(error).addClass('alert alert-danger mb-1').css("display","block");
                     }
                });
              },
              onclose: function() {
                  // close modal
              },
              customizations: {
                  title: title,
                  description: description,
                  logo: logo,
              },

          });
      }

      // Paystack
      if(payment_type == 6){

         let handler = PaystackPop.setup({

               key: $('#paystack').val(),
               email: email,
               amount: amount * 100,
               currency: 'GHS', // Use GHS for Ghana Cedis or USD for US Dollars
               ref: ''+Math.floor((Math.random() * 1000000000) + 1),
               label: title,
               onClose: function(){
               },
               callback: function(response){
                  $.ajax({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
                    url:add_wallet_url,
                    method: 'POST',
                    dataType: 'json',
                    data: {
                     payment_type : payment_type,
                        transaction_id: response.trxref,
                        amount : amount,
                        user_id : user_id ,
                    }, 
                    success: function(response) {
                         if (response.status == 1) {
                             window.location.href = wallet_url;
                         } else {
                           $('#payment_err_msg').text(response.message).addClass('alert alert-danger mb-1').css("display","block");
                         }
                     },
                     error: function(error) {
                        $('#payment_err_msg').text(error).addClass('alert alert-danger mb-1').css("display","block");
                     }
                });
               }
           });
           handler.openIframe();
      }
   }