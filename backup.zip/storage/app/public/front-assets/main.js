$(window).on('load',function(){
   "use strict";
   var x = getCookie('city_name');
   if (x) {
      $('#citiesModal').modal('hide');
   } else {
      $('#citiesModal').modal({backdrop: 'static', keyboard: false})  

   }
});


function setCookie(name,value,days) {
   "use strict";
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
    window.location.reload();
}
function getCookie(name) {
   "use strict";
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

var myCookie = getCookie("city_name");
if(myCookie){
   document.getElementById("selected_city").innerHTML = myCookie;
}


$("#ajax_city").keyup(function(){
   "use strict";
   var query = $(this).val();
   var myurl = $(this).attr('url');
   $.ajax({
      headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
      url:myurl,
      type:"GET",
      data:{'query':query},
      success:function (data) {
         $('#city_suggestion').html(data);
      }
   })
});

function clearnotification(clearurl,successurl)
{
   "use strict";
   $.ajax({
      headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
      url:clearurl,
      dataType:"json",
      success:function(response){
         window.location.href = successurl;
      }
   });
}