$('#search_by').change(function(){
"use strict";
   if($('#search_by').val() == 'provider') {
      $('#low_to_high').hide();
      $('#high_to_low').hide();
      $('#category_id').hide();
   }
   if($('#search_by').val() == 'service') {
      $('#low_to_high').show();
      $('#high_to_low').show();
      $('#category_id').show();
   }
});

var page = 1;
function next_page()
{
   "use strict";
   page++;
   var search_by = $('#search_by option:selected').val();
   var search_name = $('#search_name').val();
   var sort_by = $('#sort_by option:selected').val();
   var category = $('#category option:selected').val();
   
   next_page_data(page,search_by,search_name,sort_by,category);
};

function next_page_data(page,search_by,search_name,sort_by,category)
{
   "use strict";
   var my_url = $('#search_by').attr('data-next-page');
   $.ajax({
      headers: {
         'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
      url:my_url,
      data: {
         page: page,
         search_by:search_by,
         search_name:search_name,
         sort_by:sort_by,
         category:category
      }, 
      method: 'GET',
      beforeSend: function(){
        $('.page-loading').show();
      },
      success: function(response) {

         $('.page-loading').hide();

         if(response.count <= 0){
            $('.no-record').show();
            $('.ajax-load').hide();
            
         }else{
            $("#data").append(response.ResponseData);
         }
         
      },
      error: function(error) {
         $('#error').text(error).addClass('alert alert-danger mb-1').css("display","block");
      }
   });
}