  $(document).ready(function(){
      "use strict";
      $("#search_box").keyup(function(){
         var query = $(this).val();
         var myurl = $(this).attr('url');
         
         $.ajax({
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            url:myurl,
      
            type:"GET",
            
            data:{'query':query},
            
            success:function (data) {
               
               $('#suggestion').html(data);
            }
         })
      });
   });
    $(document).click(function() {
      "use strict";
       $('#search_box').blur(function(){
         setTimeout(function(){
           $('#suggestion').hide();
         }, 100);
       }).focus(function(){
         $('#suggestion').show();
       });
   });