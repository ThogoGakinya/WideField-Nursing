"use strict";
$('#search_by').change(function(){
    var search_by = $(this).val();
    fetch_user_booking_by(search_by);
 });
 function fetch_user_booking_by(search_by = '')
 {
    var bookings_by_url = $("#search_by").attr('url');
    $.ajax({
       url:bookings_by_url,
       method:'GET',
       data:{search_by:search_by},
       dataType:'json',
       success:function(data)
       {
         $('.bookings').html(data.bookings_by); 
       }
    })
 }


 $(document).on('keyup', '#search_booking', function(){
   var query = $(this).val();
   fetch_user_booking_data(query);
 });
 function fetch_user_booking_data(query = '')
 {
    var ajax_bookings_url = $("#search_booking").attr('url');
    $.ajax({
       url:ajax_bookings_url,
       method:'GET',
       data:{query:query},
       dataType:'json',
       success:function(data)
       {
          $('.bookings').html(data.bookings); 
       }
    })
 }

// Cancel booking
function cancelbooking(booking_id,title,yes,no,cancelurl,wrong,recordsafe) {
    swal({
       title: title,
       type: 'warning',
       showCancelButton: true,
       confirmButtonText: yes,
       cancelButtonText: no,
       closeOnConfirm: false,
       closeOnCancel: false,
       showLoaderOnConfirm: true,
    },
    function(isConfirm) {
       if (isConfirm) {
          $.ajax({
             headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
             url:cancelurl,
             data: {booking_id: booking_id,},
             method: 'POST',
             success: function(response) {
                if (response.status == 1) {
                   swal.close();
                   window.location.reload();
                } else {
                   // swal.close();
                   swal("Cancelled", response.message, "error");
                }
             },
             error: function(e) {
                // swal.close();
                swal("Cancelled", wrong , "error");
             }
          });
       } else {
          swal("Cancelled", recordsafe , "error");
       }
    });
}